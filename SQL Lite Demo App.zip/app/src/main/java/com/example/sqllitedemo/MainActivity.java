package com.example.sqllitedemo;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

/**
 * MainActivity is the entry point of the application.
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Find the WebView element in the layout
        WebView webView = findViewById(R.id.webView);

        // Set a WebViewClient to handle callbacks and events
        webView.setWebViewClient(new WebViewClient());

        // Enable JavaScript execution in the WebView
        webView.getSettings().setJavaScriptEnabled(true);

        // Load the HTML file from the assets folder
        webView.loadUrl("file:///android_asset/yourfile.html");

        // Add a JavaScript interface to communicate between Java and JavaScript
        webView.addJavascriptInterface(new WebAppInterface(this), "Android");
    }
}