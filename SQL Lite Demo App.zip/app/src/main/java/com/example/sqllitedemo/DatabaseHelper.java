package com.example.sqllitedemo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * DatabaseHelper is a helper class to manage database creation and version management.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database Name
    private static final String DATABASE_NAME = "app.db";

    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Table Name
    private static final String TABLE_NAME = "data";

    // Column Names
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_DATA = "data";

    /**
     * Constructor that takes a context and calls the super constructor.
     *
     * @param context The context to use for locating paths to the database.
     */
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * Called when the database is created for the first time.
     * This is where the creation of tables and the initial population of the tables should happen.
     *
     * @param db The database.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        // SQL command to create a new table with an auto-incrementing ID and a data column
        String createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_DATA + " TEXT)";
        db.execSQL(createTable); // Execute the SQL command
    }

    /**
     * Called when the database needs to be upgraded.
     * The implementation should use this method to drop tables, add tables, or do anything else it needs to upgrade
     * to the new schema version.
     *
     * @param db The database.
     * @param oldVersion The old database version.
     * @param newVersion The new database version.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop the old table if it exists
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        // Create tables again
        onCreate(db);
    }

    /**
     * Inserts data into the database.
     *
     * @param data The data to be inserted.
     * @return True if the insertion was successful, false otherwise.
     */
    public boolean insertData(String data) {
        // Get the database in write mode
        SQLiteDatabase db = this.getWritableDatabase();
        // Create a new map of values, where column names are the keys
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_DATA, data); // Add the data to the content values
        // Insert the new row, returning the primary key value of the new row
        long result = db.insert(TABLE_NAME, null, contentValues);
        // If result is -1, insertion failed, otherwise it was successful
        return result != -1;
    }

    /**
     * Retrieves all the data from the database.
     *
     * @return A Cursor object, which is positioned before the first entry.
     */
    public Cursor getAllData() {
        // Get the database in read mode
        SQLiteDatabase db = this.getWritableDatabase();
        // Execute a raw SQL query to get all rows from the table
        return db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
    }
}