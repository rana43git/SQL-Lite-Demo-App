package com.example.sqllitedemo;

import android.content.Context;
import android.database.Cursor;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

/**
 * WebAppInterface is a class that provides methods to interact between JavaScript running in a WebView and Android code.
 */
public class WebAppInterface {
    Context mContext;

    /**
     * Constructor to instantiate the interface and set the context.
     *
     * @param c The context in which the interface is instantiated.
     */
    WebAppInterface(Context c) {
        mContext = c;
    }

    /**
     * Show a toast from the web page.
     *
     * @param toast The text to be displayed in the toast.
     */
    @JavascriptInterface
    public void showToast(String toast) {
        // Display a toast message
        Toast.makeText(mContext, toast, Toast.LENGTH_SHORT).show();
    }

    /**
     * Save data to SQLite database.
     *
     * @param data The data to be saved in the database.
     */
    @JavascriptInterface
    public void saveData(String data) {
        // Create a new instance of DatabaseHelper
        DatabaseHelper dbHelper = new DatabaseHelper(mContext);
        // Insert data into the database
        dbHelper.insertData(data);
    }

    /**
     * Get all data from SQLite database.
     *
     * @return A string representation of all the data in the database.
     */
    @JavascriptInterface
    public String getData() {
        // Create a new instance of DatabaseHelper
        DatabaseHelper dbHelper = new DatabaseHelper(mContext);
        // Get all data from the database
        Cursor res = dbHelper.getAllData();
        StringBuilder dataBuilder = new StringBuilder();

        // Check if there is any data in the cursor
        if (res.getCount() == 0) {
            // If no data found, return a message
            return "No data found";
        }

        // Iterate through the cursor and append data to StringBuilder
        while (res.moveToNext()) {
            dataBuilder.append("ID: ").append(res.getString(0))
                    .append(", Data: ").append(res.getString(1))
                    .append("\n");
        }

        // Return the string representation of data
        return dataBuilder.toString();
    }
}